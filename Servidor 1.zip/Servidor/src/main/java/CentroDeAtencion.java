
import CACUPB.Clases.Banco;
import CACUPB.Clases.Cita;
import CACUPB.Clases.Estudiante;
import CACUPB.Clases.Ticket;
import CACUPB.DataStructures.PriorityQueue;
import CACUPB.DataStructures.SinglyLinkedList;
import CACUPB.Interface;
import CACUPB.InterfacesGraficas.GUICrearCita;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.*;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.NoSuchElementException;

public class CentroDeAtencion extends UnicastRemoteObject implements Interface {

    private static final String filePathEstudiantes = "C:/Users/JUAN DAVID FUENTES/Desktop/CAC-UPB/src/main/java/BaseDeDatos/estudiantes.json";

    private SinglyLinkedList<Cita> citas = new SinglyLinkedList<>();
    private SinglyLinkedList<Estudiante> estudiantes = new SinglyLinkedList<>();
    private PriorityQueue<Ticket> mentorias;
    private PriorityQueue<Ticket> asesorias;
    private Gson gson = new GsonBuilder().setPrettyPrinting().create();
    private Banco[] bancos;
    
    public CentroDeAtencion(int numBancos) throws RemoteException {
        try {
            this.estudiantes.add(cargarEstudiantes());
            this.mentorias = new PriorityQueue<>(2);
            this.asesorias = new PriorityQueue<>(2);
            bancos = new Banco[numBancos];
            for (int i = 0; i < numBancos; i++) {
                bancos[i] = new Banco();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public Ticket getTicket(long id) throws RemoteException {
        Date fechaHoy = new Date();
        Cita cita = buscarCitaPorId(id);
        Date fechaCita = cita.getFecha();
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

        String fechaHoyStr = sdf.format(fechaHoy);
        String fechaCitaStr = sdf.format(fechaCita);

        if (fechaHoyStr.equals(fechaCitaStr)) {
            Ticket ticket = new Ticket(buscarEstudiantePorId(id), buscarCitaPorId(id));
            if (cita.isMentoria()) {
                encolarMentorias(ticket);
            } else {
                encolarAsesorias(ticket);
            }
            return ticket;
        }
        return null;
    }

    public Estudiante buscarEstudiantePorId(long id) throws RemoteException {
        SinglyLinkedList<Estudiante> cloneList = estudiantes.cloneList();
        if (!cloneList.isEmpty()) {
            while (!cloneList.isEmpty()) {
                if (cloneList.get().getId() == id) {
                    return cloneList.get();
                } else {
                    cloneList.pop();
                }
            }
        }
        return null;
    }

    public Estudiante[] cargarEstudiantes() throws RemoteException {
        try (Reader reader = new FileReader(filePathEstudiantes)) {
            Estudiante[] UsuarioArr = gson.fromJson(reader, Estudiante[].class);
            if (UsuarioArr == null) {
                UsuarioArr = new Estudiante[0];
            }
            return UsuarioArr;
        } catch (IOException e) {
            e.printStackTrace();
            return new Estudiante[0];
        }
    }

    public boolean crearEstudiante(Long id, String password, String nombre, String apellido, boolean discapacidad, boolean primerSemestre) throws RemoteException {

        if(buscarEstudiantePorId(Math.toIntExact(id)) == null) {
            Estudiante newEstudiantes = new Estudiante(id, password, nombre, apellido, discapacidad, primerSemestre);
            estudiantes.add(newEstudiantes);
            guardarEstudiantesEnJson();
            return true;
        }
        return false;
    }

    public void addCita(Cita cita) {
        SinglyLinkedList<Cita> cloneList = citas.cloneList();
        if (!cloneList.isEmpty()) {
            while (!cloneList.isEmpty()) {
                if (cloneList.get().getFecha().equals(cita.getFecha()) && cloneList.get().getHora() == cita.getHora()) {
                    throw new IllegalArgumentException("Ya existe una cita con la misma fecha y hora.");
                } else {
                    cloneList.pop();
                }
            }
        }
        citas.add(cita);
    }

    public boolean cancelarCita(long id) throws RemoteException {
        Cita citaToRemove = buscarCitaPorId(id);
        if (citaToRemove != null) {
            System.out.println(citas.remove(citaToRemove) + "cita removida");
            System.out.println(citas.toString());
        }
        return false;
    }

    public Cita buscarCitaPorId(Long cita) {
        SinglyLinkedList<Cita> cloneList = citas.cloneList();
        if (!cloneList.isEmpty()) {
            while (!cloneList.isEmpty()) {
                if (cloneList.get().getId().equals(cita)) {
                    return cloneList.get();
                } else {
                    cloneList.pop();
                }
            }
        }

        throw new NoSuchElementException("No se encontró la cita con el ID: " + cita);
    }


    public void encolarMentorias(Ticket ticket) throws RemoteException {
        int prioridad = 0;
        if (ticket.getEstudiante().isDiscapacidad()) {
            prioridad = 0;
        } else if (ticket.getEstudiante().isPrimerSemestre()) {
            prioridad = 1;
        } else {
            prioridad = 2;
        }
        mentorias.insert(ticket, prioridad);
        System.out.println(mentorias.peek().getEstudiante().getNombre());
    }

    public void encolarAsesorias(Ticket ticket) throws RemoteException {
        int prioridad = 0;
        if (ticket.getEstudiante().isDiscapacidad()) {
            prioridad = 0;
        } else if (ticket.getEstudiante().isPrimerSemestre()) {
            prioridad = 1;
        } else {
            prioridad = 2;
        }
        asesorias.insert(ticket, prioridad);
        System.out.println(asesorias.peek().getEstudiante().getNombre());
    }

    public void crearTicket(int id) throws RemoteException {
        Ticket ticket = new Ticket(buscarEstudiantePorId(id),citas.pop());

    }

    public Estudiante getEstudianteCredenciales(int id, String password) throws RemoteException {
        SinglyLinkedList<Estudiante> cloneList = estudiantes.cloneList();
        while (!cloneList.isEmpty()) {
            if (cloneList.get().getId() == id && cloneList.get().getContrasena().equals(password)) {
                return cloneList.get();
            }else {
                cloneList.pop();
            }
        }
        return null;
    }

    public boolean validarCredenciales(int id, String password) throws RemoteException {
        SinglyLinkedList<Estudiante> cloneList = estudiantes.cloneList();
        while (!cloneList.isEmpty()) {
            if (cloneList.get().getId() == id && cloneList.get().getContrasena().equals(password)) {
                return true;
            }else {
                cloneList.pop();
            }
        }
        return false;
    }

    public void guardarEstudiantesEnJson() throws RemoteException {
        try (Writer writer = new FileWriter(filePathEstudiantes)) {
            gson.toJson(estudiantes.toArray(), writer);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public PriorityQueue<Ticket> getMentorias() {
        return mentorias;
    }

    public PriorityQueue<Ticket> getAsesorias() {
        return asesorias;
    }

    public Ticket deseconlarMentoria() throws RemoteException {
        for (Banco banco : bancos) {
            if (!banco.estaOcupado()) {
                banco.ocupar();
                return mentorias.pop();
            }
        }

        throw new NoSuchElementException("No hay bancos disponibles en este momento.");
    }

    public Ticket deseconlarTicket() throws RemoteException {
        for (Banco banco : bancos) {
            if (!banco.estaOcupado()) {
                banco.ocupar();
                return asesorias.pop();
            }
        }

        throw new NoSuchElementException("No hay bancos disponibles en este momento.");
    }

    @Override
    public GUICrearCita getModuloCita() throws RemoteException {
        GUICrearCita guiCrearCita = new GUICrearCita(buscarEstudiantePorId(496459L));
        return guiCrearCita;
    }

}
