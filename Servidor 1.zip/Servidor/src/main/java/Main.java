import java.io.Serializable;
import java.rmi.Naming;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

import static java.rmi.Naming.rebind;

public class Main implements Serializable {
    public static void main(String[] args) {
        try {
            CentroDeAtencion adminBaseDeDatos = new CentroDeAtencion(8);
            String rmiObjectName = "rmi://localhost:1099/CentroDeAtencion";

            Registry registry = LocateRegistry.createRegistry(1099);

            rebind(rmiObjectName, adminBaseDeDatos);

            System.out.println("Servidor RMI de FoodUPB listo.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
